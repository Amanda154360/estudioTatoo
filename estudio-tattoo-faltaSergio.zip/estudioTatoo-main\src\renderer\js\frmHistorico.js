let clientesCarregados = [];
let profissionaisCarregados = [];
let servicosCarregados = [];

function escapeHtml(valor) {
  if (valor === null || valor === undefined) return "";
  return String(valor)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

async function carregarCombos() {
  try {
    clientesCarregados = await window.api.listarClientes("");
    profissionaisCarregados = await window.api.listarProfissionais("", 0);
    servicosCarregados = await window.api.listarServicos({ termo: "", categoria: "", apenasAtivos: false });

    const selCliente = document.querySelector("#selectCliente");
    const selProf = document.querySelector("#selectProfissional");
    const selServ = document.querySelector("#selectServico");

    selCliente.innerHTML = clientesCarregados.map((c) => `<option value="${c.id}">${escapeHtml(c.nome)}</option>`).join("");
    selProf.innerHTML = profissionaisCarregados.map((p) => `<option value="${p.id}">${escapeHtml(p.nome)}</option>`).join("");
    selServ.innerHTML = `<option value="">(nenhum)</option>` + servicosCarregados.map((s) => `<option value="${s.id}">${escapeHtml(s.nome)}</option>`).join("");
  } catch (erro) {
    console.error("Erro ao carregar combos:", erro);
  }
}

async function carregarHistorico() {
  const clienteId = Number(document.querySelector("#selectCliente").value);
  const tbody = document.querySelector("#tbodyHistorico");
  if (!clienteId) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-muted">Selecione um cliente.</td></tr>`;
    return;
  }

  try {
    const lista = await window.api.listarHistoricoCliente(clienteId);
    if (!lista || lista.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center text-muted">Nenhum atendimento registrado.</td></tr>`;
      return;
    }

    tbody.innerHTML = lista.map((a) => `
      <tr>
        <td>${a.data_realizacao ? new Date(a.data_realizacao).toLocaleString('pt-BR') : '-'}</td>
        <td>${escapeHtml(a.cliente_nome || '')}</td>
        <td>${escapeHtml(a.profissional_nome || '')}</td>
        <td>${escapeHtml(a.servico_nome || '-')}</td>
        <td>${Number(a.valor || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
        <td>${escapeHtml(a.status)}</td>
        <td class="text-center">
          <button class="btn btn-sm btn-danger" onclick="excluirAtendimento(${a.id})">Excluir</button>
        </td>
      </tr>
    `).join("");
  } catch (erro) {
    console.error("Erro ao carregar histórico:", erro);
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Erro ao carregar histórico.</td></tr>`;
  }
}

async function registrar() {
  try {
    const clienteId = Number(document.querySelector("#selectCliente").value);
    const profissionalId = Number(document.querySelector("#selectProfissional").value);
    const servicoValue = document.querySelector("#selectServico").value;
    const servicoId = servicoValue ? Number(servicoValue) : null;
    const data = document.querySelector("#inputData").value;
    const valor = Number(document.querySelector("#inputValor").value || 0);
    const status = document.querySelector("#selectStatus").value;
    const obs = document.querySelector("#inputObs").value;

    await window.api.registrarAtendimento({
      cliente_id: clienteId,
      profissional_id: profissionalId,
      servico_id: servicoId,
      data_realizacao: data ? new Date(data).toISOString() : new Date().toISOString(),
      valor: valor,
      status: status,
      observacoes: obs || null,
    });

    document.querySelector("#inputObs").value = "";
    await carregarHistorico();
    alert("Atendimento registrado com sucesso.");
  } catch (erro) {
    console.error("Erro ao registrar atendimento:", erro);
    alert("Não foi possível registrar o atendimento.");
  }
}

async function excluirAtendimento(id) {
  if (!confirm("Excluir este atendimento do histórico?")) return;
  try {
    await window.api.excluirAtendimento(id);
    await carregarHistorico();
  } catch (erro) {
    console.error("Erro ao excluir atendimento:", erro);
    alert("Não foi possível excluir o atendimento.");
  }
}

document.querySelector("#btnRecarregar").addEventListener("click", () => {
  carregarCombos().then(carregarHistorico);
});

document.querySelector("#selectCliente").addEventListener("change", () => carregarHistorico());
document.querySelector("#btnRegistrar").addEventListener("click", () => registrar());

carregarCombos().then(carregarHistorico);
