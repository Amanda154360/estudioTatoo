import type {
  Atendimento,
  AtualizacaoAtendimento,
  DadosAtendimento,
  FiltroAtendimentos,
} from '../../../shared/contracts/atendimento';
import { atendimentoSchema } from '../../../shared/validation/atendimentoSchemas';
import { ProcedureExecutor } from '../database/ProcedureExecutor';

export class AtendimentoRepository {
  async listar(clienteId?: number): Promise<Atendimento[]> {
    const linhas =
      clienteId !== undefined
        ? await ProcedureExecutor.consultar('CALL sp_listar_historico_cliente(?)', [clienteId])
        : await ProcedureExecutor.consultar('CALL sp_listar_atendimentos()', []);

    return linhas.map((linha) => atendimentoSchema.parse(linha));
  }

  async registrar(dados: DadosAtendimento): Promise<number> {
    const linhas = await ProcedureExecutor.consultar(
      'CALL sp_registrar_atendimento(?, ?, ?, ?, ?, ?, ?)',
      [
        dados.cliente_id,
        dados.profissional_id,
        dados.servico_id,
        dados.data_realizacao,
        dados.valor,
        dados.status,
        dados.observacoes,
      ],
    );

    return Number(linhas[0]?.id ?? 0);
  }

  async atualizar(dados: AtualizacaoAtendimento): Promise<number> {
    const linhas = await ProcedureExecutor.consultar('CALL sp_atualizar_atendimento(?, ?, ?, ?, ?, ?, ?)', [
      dados.id,
      dados.profissional_id,
      dados.servico_id,
      dados.data_realizacao,
      dados.valor,
      dados.status,
      dados.observacoes,
    ]);

    return Number(linhas[0]?.linhas_afetadas ?? 0);
  }

  async excluir(id: number): Promise<number> {
    const linhas = await ProcedureExecutor.consultar('CALL sp_excluir_atendimento(?)', [id]);
    return Number(linhas[0]?.linhas_afetadas ?? 0);
  }

  async ultimaVisita(clienteId: number): Promise<Atendimento | null> {
    const lista = await this.listar(clienteId);
    if (lista.length === 0) return null;
    return lista[0] ?? null;
  }
}
