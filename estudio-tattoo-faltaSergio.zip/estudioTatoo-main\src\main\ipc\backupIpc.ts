import { dialog } from 'electron';
import { readFile, writeFile } from 'node:fs/promises';
import { z } from 'zod';
import { SegurancaIpc } from './seguranca';

/**
 * Módulo de backup em arquivo (padrão da Aula 7 - fs + dialog + JSON).
 * Exporta/importa dados já carregados na tela, sem acesso direto do renderer ao disco.
 */
export function registrarBackupIpc(): void {
  SegurancaIpc.registrarCanal('backup:exportarJson', z.string(), async (conteudo) => {
    const { canceled, filePath } = await dialog.showSaveDialog({
      title: 'Salvar backup (JSON)',
      defaultPath: 'backup-clientes.json',
      filters: [{ name: 'JSON', extensions: ['json'] }],
    });

    if (canceled || !filePath) {
      return { cancelado: true as const };
    }

    await writeFile(filePath, conteudo, 'utf-8');
    return { cancelado: false as const, caminho: filePath };
  });

  SegurancaIpc.registrarCanal('backup:importarJson', z.undefined(), async () => {
    const { canceled, filePaths } = await dialog.showOpenDialog({
      title: 'Abrir backup (JSON)',
      filters: [{ name: 'JSON', extensions: ['json'] }],
      properties: ['openFile'],
    });

    if (canceled || !filePaths || filePaths.length === 0) {
      return { cancelado: true as const };
    }

    const caminho = filePaths[0];
    if (!caminho) {
      return { cancelado: true as const };
    }

    const conteudo = await readFile(caminho, 'utf-8');
    return { cancelado: false as const, conteudo };
  });
}
