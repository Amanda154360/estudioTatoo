import type { WindowManager } from '../windows/windowManager';
import { registrarAtendimentoIpc } from './atendimentoIpc';
import { registrarBackupIpc } from './backupIpc';
import registrarCepIpc from './cepIpc';
import registrarClienteIpc from './clienteIpc';
import registrarProfissionalIpc from './profissionalIpc';
import { registrarLembreteIpc } from './lembreteIpc';
import { registrarServicoIpc } from './servicoIpc';

export function registrarTodosIpcs(windowManager: WindowManager): void {
  // Módulos legados (JS) — portados para TS na próxima fase.
  registrarCepIpc();
  registrarClienteIpc(windowManager);
  registrarProfissionalIpc(windowManager);

  // Backup em arquivo (JSON), conforme Aula 7 (fs + dialog).
  registrarBackupIpc();

  // Módulos novos, 100% TypeScript.
  registrarServicoIpc();
  registrarLembreteIpc();
  registrarAtendimentoIpc();
}
