import { contextBridge, ipcRenderer } from 'electron';
import { CANAIS, type ApiEstudio } from '../shared/contracts/ipc';

const api: ApiEstudio = {
  // ==========================================
  // CLIENTES
  // ==========================================
  criarCliente: (dados) => ipcRenderer.invoke('cliente:criar', dados),
  listarClientes: (filtro) => ipcRenderer.invoke('cliente:listar', filtro),
  abrirEdicaoCliente: (cliente) => ipcRenderer.send('cliente:abrirEdicao', cliente),
  abrirNovoCliente: () => ipcRenderer.send('cliente:abrirNovo'),
  atualizarCliente: (dados) => ipcRenderer.invoke('cliente:atualizar', dados),
  excluirCliente: (id) => ipcRenderer.invoke('cliente:excluir', id),
  buscarClientesPorCep: (cep) => ipcRenderer.invoke('cliente:buscarPorCep', cep),
  aoReceberClienteParaEditar: (callback) => {
    ipcRenderer.on('cliente:preencher', (_evento, cliente: unknown) => callback(cliente));
  },

  // ==========================================
  // PROFISSIONAIS
  // ==========================================
  criarProfissional: (dados) => ipcRenderer.invoke('profissional:criar', dados),
  listarProfissionais: (especialidade, apenasAtivos) =>
    ipcRenderer.invoke('profissional:listar', especialidade, apenasAtivos),
  abrirEdicaoProfissional: (profissional) =>
    ipcRenderer.send('profissional:abrirEdicao', profissional),
  abrirNovoProfissional: () => ipcRenderer.send('profissional:abrirNovo'),
  atualizarProfissional: (dados) => ipcRenderer.invoke('profissional:atualizar', dados),
  excluirProfissional: (id) => ipcRenderer.invoke('profissional:excluir', id),
  aoReceberProfissionalParaEditar: (callback) => {
    ipcRenderer.on('profissional:preencher', (_evento, profissional: unknown) =>
      callback(profissional),
    );
  },

  // ==========================================
  // CEP
  // ==========================================
  buscarCepSql: (cep) => ipcRenderer.invoke('sql:buscarCep', cep),

  // ==========================================
  // PROCEDIMENTOS DO ESTÚDIO
  // ==========================================
  listarServicos: (filtro) => ipcRenderer.invoke(CANAIS.servicoListar, filtro),
  buscarServico: (id) => ipcRenderer.invoke(CANAIS.servicoBuscar, id),
  criarServico: (dados) => ipcRenderer.invoke(CANAIS.servicoCriar, dados),
  atualizarServico: (dados) => ipcRenderer.invoke(CANAIS.servicoAtualizar, dados),
  excluirServico: (id) => ipcRenderer.invoke(CANAIS.servicoExcluir, id),

  // ==========================================
  // LEMBRETES DE ATENDIMENTO
  // ==========================================
  listarLembretes: (filtro) => ipcRenderer.invoke(CANAIS.lembreteListar, filtro),
  gerarLembretesPendentes: () => ipcRenderer.invoke(CANAIS.lembreteGerarPendentes, undefined),
  enviarLembretesPendentes: () => ipcRenderer.invoke(CANAIS.lembreteEnviarPendentes, undefined),
  reprocessarLembrete: (id) => ipcRenderer.invoke(CANAIS.lembreteReprocessar, id),
  cancelarLembrete: (id) => ipcRenderer.invoke(CANAIS.lembreteCancelar, id),
  excluirLembrete: (id) => ipcRenderer.invoke(CANAIS.lembreteExcluir, id),
  criarLembreteManual: (agendamentoId) =>
    ipcRenderer.invoke(CANAIS.lembreteCriarManual, agendamentoId),

  // ==========================================
  // SISTEMA
  // ==========================================
  aoRecarregar: (callback) => {
    ipcRenderer.on('sistema:recarregar', () => callback());
  },

  // ==========================================
  // BACKUP EM ARQUIVO (JSON)
  // ==========================================
  exportarBackupJson: (conteudo) => ipcRenderer.invoke('backup:exportarJson', conteudo),
  importarBackupJson: () => ipcRenderer.invoke('backup:importarJson'),

  // ==========================================
  // HISTÓRICO DO CLIENTE (ATENDIMENTOS)
  // ==========================================
  listarAtendimentos: (filtro) => ipcRenderer.invoke(CANAIS.atendimentoListar, filtro),
  listarHistoricoCliente: (clienteId) => ipcRenderer.invoke(CANAIS.atendimentoListarPorCliente, clienteId),
  registrarAtendimento: (dados) => ipcRenderer.invoke(CANAIS.atendimentoRegistrar, dados),
  atualizarAtendimento: (dados) => ipcRenderer.invoke(CANAIS.atendimentoAtualizar, dados),
  excluirAtendimento: (id) => ipcRenderer.invoke(CANAIS.atendimentoExcluir, id),
  ultimaVisitaCliente: (clienteId) => ipcRenderer.invoke(CANAIS.atendimentoUltimaVisita, clienteId),
};

contextBridge.exposeInMainWorld('api', api);
