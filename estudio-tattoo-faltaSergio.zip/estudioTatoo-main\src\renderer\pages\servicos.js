/* Arquivo gerado por scripts/build.mjs. Edite o .ts correspondente. */
"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };

  // src/renderer/components/dom.ts
  function exigirElemento(seletor) {
    const elemento = document.querySelector(seletor);
    if (!elemento) {
      throw new Error(`Elemento obrigat\xF3rio n\xE3o encontrado: ${seletor}`);
    }
    return elemento;
  }
  function criarCelula(texto, classe) {
    const celula = document.createElement("td");
    celula.textContent = texto;
    if (classe) celula.className = classe;
    return celula;
  }
  function criarBotao(texto, classe, aoClicar) {
    const botao = document.createElement("button");
    botao.type = "button";
    botao.className = classe;
    botao.textContent = texto;
    botao.addEventListener("click", aoClicar);
    return botao;
  }
  function mostrarAviso(mensagem, tipo = "info") {
    const area = document.querySelector("#areaAvisos");
    if (!area) {
      window.alert(mensagem);
      return;
    }
    const classe = tipo === "sucesso" ? "alert-success" : tipo === "erro" ? "alert-danger" : "alert-info";
    const alerta = document.createElement("div");
    alerta.className = `alert ${classe} py-2 mb-2`;
    alerta.textContent = mensagem;
    area.prepend(alerta);
    window.setTimeout(() => alerta.remove(), 8e3);
  }
  function mensagemDeErro(erro, padrao) {
    if (!(erro instanceof Error)) return padrao;
    const limpa = erro.message.replace(/^Error invoking remote method '[^']+':\s*(Error:\s*)?/, "");
    return limpa.trim() || padrao;
  }
  function formatarMoeda(valor) {
    return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }
  function formatarDuracao(minutos) {
    if (minutos < 60) return `${minutos} min`;
    const horas = Math.floor(minutos / 60);
    const resto = minutos % 60;
    return resto === 0 ? `${horas}h` : `${horas}h${String(resto).padStart(2, "0")}`;
  }
  var init_dom = __esm({
    "src/renderer/components/dom.ts"() {
      "use strict";
    }
  });

  // src/renderer/pages/servicos.ts
  var require_servicos = __commonJS({
    "src/renderer/pages/servicos.ts"() {
      init_dom();
      var servicos = [];
      var idEmEdicao = null;
      var corpoTabela = exigirElemento("#corpoTabela");
      var contador = exigirElemento("#contador");
      var campoBusca = exigirElemento("#campoBusca");
      var filtroCategoria = exigirElemento("#filtroCategoria");
      var checkApenasAtivos = exigirElemento("#checkApenasAtivos");
      var form = exigirElemento("#formServico");
      var modalElemento = exigirElemento("#modalServico");
      var tituloModal = exigirElemento("#tituloModal");
      var erroFormulario = exigirElemento("#erroFormulario");
      var btnSalvar = exigirElemento("#btnSalvar");
      var modal = new window.bootstrap.Modal(modalElemento);
      function categoriaDoFiltro() {
        return filtroCategoria.value;
      }
      async function carregar() {
        try {
          servicos = await window.api.listarServicos({
            termo: campoBusca.value.trim(),
            categoria: categoriaDoFiltro(),
            apenasAtivos: checkApenasAtivos.checked
          });
          renderizar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel carregar os procedimentos."), "erro");
        }
      }
      function renderizar() {
        corpoTabela.replaceChildren();
        contador.textContent = `${servicos.length} procedimento(s)`;
        if (servicos.length === 0) {
          const linha = document.createElement("tr");
          const celula = criarCelula("Nenhum procedimento encontrado.", "text-center text-muted");
          celula.colSpan = 6;
          linha.append(celula);
          corpoTabela.append(linha);
          return;
        }
        for (const servico of servicos) {
          const linha = document.createElement("tr");
          linha.append(criarCelula(servico.nome));
          linha.append(criarCelula(servico.categoria));
          linha.append(criarCelula(formatarMoeda(servico.preco_base)));
          linha.append(criarCelula(formatarDuracao(servico.duracao_minutos)));
          linha.append(criarStatus(servico));
          linha.append(criarAcoes(servico));
          corpoTabela.append(linha);
        }
      }
      function criarStatus(servico) {
        const celula = document.createElement("td");
        const badge = document.createElement("span");
        badge.className = `badge ${servico.ativo ? "bg-success" : "bg-secondary"}`;
        badge.textContent = servico.ativo ? "Ativo" : "Inativo";
        celula.append(badge);
        return celula;
      }
      function criarAcoes(servico) {
        const celula = document.createElement("td");
        celula.className = "text-center";
        const grupo = document.createElement("div");
        grupo.className = "btn-group btn-group-sm";
        grupo.append(
          criarBotao("Editar", "btn btn-primary", () => abrirFormulario(servico)),
          criarBotao(
            servico.ativo ? "Desativar" : "Ativar",
            "btn btn-outline-secondary",
            () => void alternarAtivo(servico)
          ),
          criarBotao("Excluir", "btn btn-danger", () => void excluir(servico))
        );
        celula.append(grupo);
        return celula;
      }
      function abrirFormulario(servico) {
        idEmEdicao = servico ? servico.id : null;
        tituloModal.textContent = servico ? "Editar procedimento" : "Novo procedimento";
        erroFormulario.classList.add("d-none");
        erroFormulario.textContent = "";
        exigirElemento("#campoId").value = servico ? String(servico.id) : "";
        exigirElemento("#campoNome").value = servico?.nome ?? "";
        exigirElemento("#campoCategoria").value = servico?.categoria ?? "Tatuagem";
        exigirElemento("#campoPreco").value = servico ? servico.preco_base.toFixed(2) : "";
        exigirElemento("#campoDuracao").value = servico ? String(servico.duracao_minutos) : "60";
        exigirElemento("#campoDescricao").value = servico?.descricao ?? "";
        exigirElemento("#campoAtivo").checked = servico ? servico.ativo : true;
        modal.show();
      }
      function dadosDoFormulario() {
        return {
          nome: exigirElemento("#campoNome").value,
          categoria: exigirElemento("#campoCategoria").value,
          preco_base: Number(exigirElemento("#campoPreco").value),
          duracao_minutos: Number(exigirElemento("#campoDuracao").value),
          descricao: exigirElemento("#campoDescricao").value,
          ativo: exigirElemento("#campoAtivo").checked
        };
      }
      function dadosDe(servico) {
        return {
          nome: servico.nome,
          categoria: servico.categoria,
          preco_base: servico.preco_base,
          duracao_minutos: servico.duracao_minutos,
          descricao: servico.descricao,
          ativo: servico.ativo
        };
      }
      async function alternarAtivo(servico) {
        try {
          await window.api.atualizarServico({ id: servico.id, ...dadosDe(servico), ativo: !servico.ativo });
          mostrarAviso(
            `Procedimento ${servico.ativo ? "desativado" : "ativado"} com sucesso.`,
            "sucesso"
          );
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel alterar o status do procedimento."), "erro");
        }
      }
      async function excluir(servico) {
        const confirmado = window.confirm(
          `Excluir o procedimento "${servico.nome}"? Esta a\xE7\xE3o n\xE3o pode ser desfeita.`
        );
        if (!confirmado) return;
        try {
          await window.api.excluirServico(servico.id);
          mostrarAviso("Procedimento exclu\xEDdo com sucesso.", "sucesso");
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel excluir o procedimento."), "erro");
        }
      }
      form.addEventListener("submit", async (evento) => {
        evento.preventDefault();
        erroFormulario.classList.add("d-none");
        btnSalvar.disabled = true;
        try {
          const dados = dadosDoFormulario();
          if (idEmEdicao === null) {
            await window.api.criarServico(dados);
            mostrarAviso("Procedimento cadastrado com sucesso.", "sucesso");
          } else {
            await window.api.atualizarServico({ ...dados, id: idEmEdicao });
            mostrarAviso("Procedimento atualizado com sucesso.", "sucesso");
          }
          modal.hide();
          await carregar();
        } catch (erro) {
          erroFormulario.textContent = mensagemDeErro(erro, "N\xE3o foi poss\xEDvel salvar o procedimento.");
          erroFormulario.classList.remove("d-none");
        } finally {
          btnSalvar.disabled = false;
        }
      });
      exigirElemento("#btnNovo").addEventListener("click", () => abrirFormulario(null));
      exigirElemento("#btnAtualizar").addEventListener("click", () => void carregar());
      campoBusca.addEventListener("keydown", (evento) => {
        if (evento.key === "Enter") {
          evento.preventDefault();
          void carregar();
        }
      });
      filtroCategoria.addEventListener("change", () => void carregar());
      checkApenasAtivos.addEventListener("change", () => void carregar());
      void carregar();
    }
  });
  require_servicos();
})();
//# sourceMappingURL=servicos.js.map
