-- =============================================================================
-- M�"DULO 13: TABELA E VIEW DE HIST�"RICO DO CLIENTE (ATENDIMENTOS)
-- =============================================================================

USE estudio_tattoo;

DROP VIEW IF EXISTS vw_historico_cliente;
DROP TABLE IF EXISTS atendimentos;

-- Hist�"rico do que o cliente j� fez no est�dio (backup do atendimento).
CREATE TABLE atendimentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  profissional_id INT NOT NULL,
  servico_id INT NULL,
  data_realizacao DATETIME NOT NULL,
  valor DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  status ENUM('Realizado', 'Cancelado') NOT NULL DEFAULT 'Realizado',
  observacoes TEXT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_atendimento_cliente
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE,
  CONSTRAINT fk_atendimento_profissional
    FOREIGN KEY (profissional_id) REFERENCES profissionais(id) ON DELETE RESTRICT,
  CONSTRAINT fk_atendimento_servico
    FOREIGN KEY (servico_id) REFERENCES servicos(id) ON DELETE SET NULL,
  INDEX idx_atendimentos_cliente (cliente_id),
  INDEX idx_atendimentos_data (data_realizacao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE VIEW vw_historico_cliente AS
SELECT
  a.id,
  a.cliente_id,
  c.nome AS cliente_nome,
  a.profissional_id,
  p.nome AS profissional_nome,
  a.servico_id,
  s.nome AS servico_nome,
  a.data_realizacao,
  a.valor,
  a.status,
  a.observacoes,
  a.criado_em
FROM atendimentos a
JOIN clientes c ON c.id = a.cliente_id
JOIN profissionais p ON p.id = a.profissional_id
LEFT JOIN servicos s ON s.id = a.servico_id;
