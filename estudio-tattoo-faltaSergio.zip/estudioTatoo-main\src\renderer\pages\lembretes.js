/* Arquivo gerado por scripts/build.mjs. Edite o .ts correspondente. */
"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };

  // src/renderer/components/dom.ts
  function exigirElemento(seletor) {
    const elemento = document.querySelector(seletor);
    if (!elemento) {
      throw new Error(`Elemento obrigat\xF3rio n\xE3o encontrado: ${seletor}`);
    }
    return elemento;
  }
  function criarCelula(texto, classe) {
    const celula = document.createElement("td");
    celula.textContent = texto;
    if (classe) celula.className = classe;
    return celula;
  }
  function criarBotao(texto, classe, aoClicar) {
    const botao = document.createElement("button");
    botao.type = "button";
    botao.className = classe;
    botao.textContent = texto;
    botao.addEventListener("click", aoClicar);
    return botao;
  }
  function mostrarAviso(mensagem, tipo = "info") {
    const area = document.querySelector("#areaAvisos");
    if (!area) {
      window.alert(mensagem);
      return;
    }
    const classe = tipo === "sucesso" ? "alert-success" : tipo === "erro" ? "alert-danger" : "alert-info";
    const alerta = document.createElement("div");
    alerta.className = `alert ${classe} py-2 mb-2`;
    alerta.textContent = mensagem;
    area.prepend(alerta);
    window.setTimeout(() => alerta.remove(), 8e3);
  }
  function mensagemDeErro(erro, padrao) {
    if (!(erro instanceof Error)) return padrao;
    const limpa = erro.message.replace(/^Error invoking remote method '[^']+':\s*(Error:\s*)?/, "");
    return limpa.trim() || padrao;
  }
  function formatarDataHora(iso) {
    return new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  }
  var init_dom = __esm({
    "src/renderer/components/dom.ts"() {
      "use strict";
    }
  });

  // src/renderer/pages/lembretes.ts
  var require_lembretes = __commonJS({
    "src/renderer/pages/lembretes.ts"() {
      init_dom();
      var lembretes = [];
      var corpoTabela = exigirElemento("#corpoTabela");
      var contador = exigirElemento("#contador");
      var filtroStatus = exigirElemento("#filtroStatus");
      var campoAgendamento = exigirElemento("#campoAgendamento");
      var areaPreview = exigirElemento("#areaPreview");
      function statusSelecionado() {
        return filtroStatus.value;
      }
      async function carregar() {
        try {
          lembretes = await window.api.listarLembretes({
            status: statusSelecionado(),
            limite: 100
          });
          renderizar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel carregar os lembretes."), "erro");
        }
      }
      function renderizar() {
        corpoTabela.replaceChildren();
        contador.textContent = `${lembretes.length} lembrete(s)`;
        if (lembretes.length === 0) {
          const linha = document.createElement("tr");
          const celula = criarCelula("Nenhum lembrete encontrado.", "text-center text-muted");
          celula.colSpan = 8;
          linha.append(celula);
          corpoTabela.append(linha);
          return;
        }
        for (const lembrete of lembretes) {
          const linha = document.createElement("tr");
          linha.append(criarCelula(lembrete.cliente_nome));
          linha.append(criarCelula(formatarDataHora(lembrete.data_atendimento)));
          linha.append(criarCelula(lembrete.servico_nome ?? "-"));
          linha.append(criarCelula(lembrete.destinatario));
          linha.append(criarCelula(formatarDataHora(lembrete.enviar_em)));
          linha.append(criarStatus(lembrete));
          linha.append(criarCelula(String(lembrete.tentativas), "text-center"));
          linha.append(criarAcoes(lembrete));
          corpoTabela.append(linha);
        }
      }
      function criarStatus(lembrete) {
        const celula = document.createElement("td");
        const badge = document.createElement("span");
        const classe = {
          Pendente: "bg-warning text-dark",
          Enviado: "bg-success",
          Falhou: "bg-danger",
          Cancelado: "bg-secondary"
        };
        badge.className = `badge ${classe[lembrete.status]}`;
        badge.textContent = lembrete.status;
        celula.append(badge);
        if (lembrete.erro) {
          const detalhe = document.createElement("div");
          detalhe.className = "small text-danger text-truncate";
          detalhe.style.maxWidth = "180px";
          detalhe.textContent = lembrete.erro;
          detalhe.title = lembrete.erro;
          celula.append(detalhe);
        }
        return celula;
      }
      function criarAcoes(lembrete) {
        const celula = document.createElement("td");
        celula.className = "text-center";
        const grupo = document.createElement("div");
        grupo.className = "btn-group btn-group-sm";
        if (lembrete.status === "Pendente" || lembrete.status === "Falhou") {
          grupo.append(
            criarBotao("Reprocessar", "btn btn-outline-primary", () => void reprocessar(lembrete.id))
          );
        }
        if (lembrete.status === "Pendente" || lembrete.status === "Falhou") {
          grupo.append(criarBotao("Cancelar", "btn btn-outline-warning", () => void cancelar(lembrete.id)));
        }
        grupo.append(criarBotao("Excluir", "btn btn-danger", () => void excluir(lembrete.id)));
        celula.append(grupo);
        return celula;
      }
      async function gerarPendentes() {
        try {
          const criados = await window.api.gerarLembretesPendentes();
          mostrarAviso(
            criados > 0 ? `${criados} lembrete(s) criado(s) para os pr\xF3ximos atendimentos.` : "Nenhum agendamento novo precisava de lembrete.",
            criados > 0 ? "sucesso" : "info"
          );
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel gerar os lembretes pendentes."), "erro");
        }
      }
      async function enviarPendentes() {
        const botao = exigirElemento("#btnEnviar");
        botao.disabled = true;
        try {
          const resultado = await window.api.enviarLembretesPendentes();
          mostrarAviso(
            `Total: ${resultado.total} \u2022 enviados: ${resultado.enviados} \u2022 falhas: ${resultado.falhas}`,
            resultado.falhas > 0 ? "erro" : "sucesso"
          );
          exibirPreviews(resultado.detalhes.filter((item) => item.previewUrl));
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel enviar os lembretes."), "erro");
        } finally {
          botao.disabled = false;
        }
      }
      function exibirPreviews(previews) {
        areaPreview.replaceChildren();
        if (previews.length === 0) return;
        const cartao = document.createElement("div");
        cartao.className = "alert alert-info py-2";
        const titulo = document.createElement("strong");
        titulo.textContent = "E-mails de teste (Ethereal) gerados: ";
        cartao.append(titulo);
        for (const item of previews) {
          if (!item.previewUrl) continue;
          const linha = document.createElement("div");
          linha.className = "small mt-1";
          const codigo = document.createElement("code");
          codigo.textContent = item.previewUrl;
          linha.append(`#${item.id} `, codigo);
          cartao.append(linha);
        }
        areaPreview.append(cartao);
      }
      async function reprocessar(id) {
        try {
          await window.api.reprocessarLembrete(id);
          mostrarAviso("Lembrete marcado como pendente novamente.", "sucesso");
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel reprocessar o lembrete."), "erro");
        }
      }
      async function cancelar(id) {
        try {
          await window.api.cancelarLembrete(id);
          mostrarAviso("Lembrete cancelado.", "sucesso");
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel cancelar o lembrete."), "erro");
        }
      }
      async function excluir(id) {
        if (!window.confirm("Excluir este lembrete? Esta a\xE7\xE3o n\xE3o pode ser desfeita.")) return;
        try {
          await window.api.excluirLembrete(id);
          mostrarAviso("Lembrete exclu\xEDdo.", "sucesso");
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel excluir o lembrete."), "erro");
        }
      }
      async function criarManual() {
        const agendamentoId = Number(campoAgendamento.value);
        if (!Number.isInteger(agendamentoId) || agendamentoId <= 0) {
          mostrarAviso("Informe um n\xFAmero de agendamento v\xE1lido.", "erro");
          return;
        }
        try {
          const criado = await window.api.criarLembreteManual(agendamentoId);
          mostrarAviso(`Lembrete criado para ${criado.cliente_nome}.`, "sucesso");
          campoAgendamento.value = "";
          await carregar();
        } catch (erro) {
          mostrarAviso(mensagemDeErro(erro, "N\xE3o foi poss\xEDvel criar o lembrete manual."), "erro");
        }
      }
      exigirElemento("#btnAtualizar").addEventListener("click", () => void carregar());
      exigirElemento("#btnGerar").addEventListener("click", () => void gerarPendentes());
      exigirElemento("#btnEnviar").addEventListener("click", () => void enviarPendentes());
      exigirElemento("#btnCriarManual").addEventListener("click", () => void criarManual());
      filtroStatus.addEventListener("change", () => void carregar());
      void carregar();
    }
  });
  require_lembretes();
})();
//# sourceMappingURL=lembretes.js.map
