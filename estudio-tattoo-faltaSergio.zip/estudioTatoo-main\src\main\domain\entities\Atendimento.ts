import type {
  Atendimento as AtendimentoDto,
  DadosAtendimento,
  StatusAtendimento,
} from '../../../shared/contracts/atendimento';

export class Atendimento {
  private constructor(private readonly dados: AtendimentoDto) {}

  static reconstituir(dados: AtendimentoDto): Atendimento {
    return new Atendimento({ ...dados });
  }

  static novo(dados: DadosAtendimento): Atendimento {
    const registro: AtendimentoDto = {
      id: 0,
      cliente_id: dados.cliente_id,
      profissional_id: dados.profissional_id,
      servico_id: dados.servico_id,
      servico_nome: null,
      data_realizacao: dados.data_realizacao,
      valor: dados.valor,
      status: dados.status,
      observacoes: dados.observacoes?.trim() ? dados.observacoes.trim() : null,
      criado_em: new Date().toISOString(),
    };

    Atendimento.garantirInvariantes(registro);
    return new Atendimento(registro);
  }

  private static garantirInvariantes(dados: AtendimentoDto): void {
    if (!Number.isInteger(dados.cliente_id) || dados.cliente_id <= 0) {
      throw new Error('Cliente inválido para o atendimento.');
    }
    if (!Number.isInteger(dados.profissional_id) || dados.profissional_id <= 0) {
      throw new Error('Profissional inválido para o atendimento.');
    }
    if (dados.servico_id !== null && (!Number.isInteger(dados.servico_id) || dados.servico_id <= 0)) {
      throw new Error('Serviço inválido para o atendimento.');
    }
    if (!Number.isFinite(dados.valor) || dados.valor < 0) {
      throw new Error('O valor do atendimento não pode ser negativo.');
    }
  }

  get id(): number {
    return this.dados.id;
  }

  get clienteId(): number {
    return this.dados.cliente_id;
  }

  get profissionalId(): number {
    return this.dados.profissional_id;
  }

  get servicoId(): number | null {
    return this.dados.servico_id;
  }

  get dataRealizacao(): string {
    return this.dados.data_realizacao;
  }

  get valor(): number {
    return this.dados.valor;
  }

  get status(): StatusAtendimento {
    return this.dados.status;
  }

  get observacoes(): string | null {
    return this.dados.observacoes;
  }

  toDto(): AtendimentoDto {
    return { ...this.dados };
  }

  static dadosDe(dados: AtendimentoDto): DadosAtendimento {
    return {
      cliente_id: dados.cliente_id,
      profissional_id: dados.profissional_id,
      servico_id: dados.servico_id,
      data_realizacao: dados.data_realizacao,
      valor: dados.valor,
      status: dados.status,
      observacoes: dados.observacoes,
    };
  }
}
