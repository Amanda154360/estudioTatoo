import type {
  Atendimento as AtendimentoDto,
  AtualizacaoAtendimento,
  DadosAtendimento,
  FiltroAtendimentos,
} from '../../shared/contracts/atendimento';
import { Atendimento } from '../domain/entities/Atendimento';
import { AtendimentoRepository } from '../infra/repositories/AtendimentoRepository';

export class AtendimentoService {
  constructor(private readonly repositorio: AtendimentoRepository = new AtendimentoRepository()) {}

  async listar(filtro: FiltroAtendimentos): Promise<AtendimentoDto[]> {
    return this.repositorio.listar(filtro.clienteId);
  }

  async listarHistoricoCliente(clienteId: number): Promise<AtendimentoDto[]> {
    return this.repositorio.listar(clienteId);
  }

  async registrar(dados: DadosAtendimento): Promise<AtendimentoDto> {
    const dominio = Atendimento.novo(dados);
    const id = await this.repositorio.registrar(Atendimento.dadosDe(dominio.toDto()));
    const lista = await this.repositorio.listar(dados.cliente_id);
    const criado = lista.find((item) => item.id === id);
    if (!criado) {
      throw new Error('Não foi possível recarregar o atendimento registrado.');
    }
    return criado;
  }

  async atualizar(dados: AtualizacaoAtendimento): Promise<AtendimentoDto> {
    const linhas = await this.repositorio.atualizar(dados);
    if (linhas === 0) {
      throw new Error('Não foi possível atualizar o atendimento.');
    }
    const lista = await this.repositorio.listar(dados.cliente_id);
    const atualizado = lista.find((item) => item.id === dados.id);
    if (!atualizado) {
      throw new Error('Não foi possível recarregar o atendimento atualizado.');
    }
    return atualizado;
  }

  async excluir(id: number): Promise<void> {
    const linhas = await this.repositorio.excluir(id);
    if (linhas === 0) {
      throw new Error('Atendimento não encontrado.');
    }
  }

  async ultimaVisita(clienteId: number): Promise<AtendimentoDto | null> {
    return this.repositorio.ultimaVisita(clienteId);
  }
}
