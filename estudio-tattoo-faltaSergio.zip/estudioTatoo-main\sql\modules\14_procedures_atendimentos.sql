-- =============================================================================
-- M�"DULO 14: PROCEDURES DE HIST�"RICO DO CLIENTE (ATENDIMENTOS)
-- =============================================================================

USE estudio_tattoo;

DROP PROCEDURE IF EXISTS sp_registrar_atendimento;
DROP PROCEDURE IF EXISTS sp_listar_historico_cliente;
DROP PROCEDURE IF EXISTS sp_ultima_visita_cliente;
DROP PROCEDURE IF EXISTS sp_listar_atendimentos;
DROP PROCEDURE IF EXISTS sp_atualizar_atendimento;
DROP PROCEDURE IF EXISTS sp_excluir_atendimento;

DELIMITER $$

-- 1. REGISTRAR ATENDIMENTO (hist�"rico do cliente)
CREATE PROCEDURE sp_registrar_atendimento(
  IN p_cliente_id INT,
  IN p_profissional_id INT,
  IN p_servico_id INT,
  IN p_data_realizacao DATETIME,
  IN p_valor DECIMAL(10,2),
  IN p_status VARCHAR(20),
  IN p_observacoes TEXT
)
BEGIN
  IF NOT EXISTS (SELECT 1 FROM clientes WHERE id = p_cliente_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cliente n�o encontrado.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM profissionais WHERE id = p_profissional_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Profissional n�o encontrado.';
  END IF;

  INSERT INTO atendimentos (cliente_id, profissional_id, servico_id, data_realizacao, valor, status, observacoes)
  VALUES (
    p_cliente_id,
    p_profissional_id,
    p_servico_id,
    p_data_realizacao,
    IFNULL(p_valor, 0.00),
    IFNULL(NULLIF(TRIM(p_status), ''), 'Realizado'),
    NULLIF(TRIM(p_observacoes), '')
  );

  SELECT LAST_INSERT_ID() AS id;
END$$

-- 2. LISTAR HIST�"RICO DE UM CLIENTE
CREATE PROCEDURE sp_listar_historico_cliente(IN p_cliente_id INT)
BEGIN
  SELECT *
  FROM vw_historico_cliente
  WHERE cliente_id = p_cliente_id
  ORDER BY data_realizacao DESC;
END$$

-- 3. �?LTIMA VISITA DO CLIENTE
CREATE PROCEDURE sp_ultima_visita_cliente(IN p_cliente_id INT)
BEGIN
  SELECT
    cliente_id,
    cliente_nome,
    MAX(data_realizacao) AS ultima_visita,
    COUNT(*) AS total_atendimentos
  FROM vw_historico_cliente
  WHERE cliente_id = p_cliente_id
  GROUP BY cliente_id, cliente_nome;
END$$

-- 4. LISTAR TODOS OS ATENDIMENTOS
CREATE PROCEDURE sp_listar_atendimentos()
BEGIN
  SELECT *
  FROM vw_historico_cliente
  ORDER BY data_realizacao DESC;
END$$

-- 5. ATUALIZAR ATENDIMENTO
CREATE PROCEDURE sp_atualizar_atendimento(
  IN p_id INT,
  IN p_profissional_id INT,
  IN p_servico_id INT,
  IN p_data_realizacao DATETIME,
  IN p_valor DECIMAL(10,2),
  IN p_status VARCHAR(20),
  IN p_observacoes TEXT
)
BEGIN
  IF NOT EXISTS (SELECT 1 FROM atendimentos WHERE id = p_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Atendimento n�o encontrado.';
  END IF;

  UPDATE atendimentos SET
    profissional_id = p_profissional_id,
    servico_id = p_servico_id,
    data_realizacao = p_data_realizacao,
    valor = IFNULL(p_valor, valor),
    status = IFNULL(NULLIF(TRIM(p_status), ''), status),
    observacoes = NULLIF(TRIM(p_observacoes), '')
  WHERE id = p_id;

  SELECT ROW_COUNT() AS linhas_afetadas;
END$$

-- 6. EXCLUIR ATENDIMENTO
CREATE PROCEDURE sp_excluir_atendimento(IN p_id INT)
BEGIN
  DELETE FROM atendimentos WHERE id = p_id;
  SELECT ROW_COUNT() AS linhas_afetadas;
END$$

DELIMITER ;
