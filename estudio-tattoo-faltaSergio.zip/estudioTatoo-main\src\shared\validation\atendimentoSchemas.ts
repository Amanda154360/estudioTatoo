import { z } from 'zod';
import { STATUS_ATENDIMENTO } from '../contracts/atendimento';

export const dadosAtendimentoSchema = z.object({
  cliente_id: z.coerce.number().int().positive('Cliente inválido.'),
  profissional_id: z.coerce.number().int().positive('Profissional inválido.'),
  servico_id: z.coerce
    .number()
    .int()
    .positive('Serviço inválido.')
    .nullish()
    .transform((valor) => (valor ? valor : null)),
  data_realizacao: z.coerce.date({ message: 'Data de realização inválida.' }).transform((valor) => valor.toISOString()),
  valor: z.coerce.number().min(0, 'O valor não pode ser negativo.').max(999999.99, 'Valor acima do limite.'),
  status: z.enum(STATUS_ATENDIMENTO).default('Realizado'),
  observacoes: z
    .string()
    .trim()
    .max(2000, 'Observações podem ter no máximo 2000 caracteres.')
    .nullish()
    .transform((valor) => (valor && valor.length > 0 ? valor : null)),
});

export const atualizacaoAtendimentoSchema = dadosAtendimentoSchema.extend({
  id: z.coerce.number().int().positive('Identificador inválido.'),
});

export const filtroAtendimentosSchema = z.object({
  clienteId: z.coerce.number().int().positive().optional(),
});

/** Valida o que vem do banco. */
export const atendimentoSchema = z.object({
  id: z.coerce.number().int().positive(),
  cliente_id: z.coerce.number().int().positive(),
  cliente_nome: z.string().optional(),
  profissional_id: z.coerce.number().int().positive(),
  profissional_nome: z.string().optional(),
  servico_id: z.coerce.number().int().positive().nullable().optional().transform((v) => (v ?? null)),
  servico_nome: z.string().nullable().optional().transform((v) => (v ?? null)),
  data_realizacao: z.union([z.string(), z.date()]).transform((v) => new Date(v).toISOString()),
  valor: z.coerce.number().nonnegative(),
  status: z.enum(STATUS_ATENDIMENTO),
  observacoes: z.string().nullable(),
  criado_em: z.union([z.string(), z.date()]).transform((v) => new Date(v).toISOString()),
});

export type DadosAtendimentoValidado = z.infer<typeof dadosAtendimentoSchema>;
export type FiltroAtendimentosValidado = z.infer<typeof filtroAtendimentosSchema>;
