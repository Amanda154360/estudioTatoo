export const STATUS_ATENDIMENTO = ['Realizado', 'Cancelado'] as const;
export type StatusAtendimento = (typeof STATUS_ATENDIMENTO)[number];

export interface Atendimento {
  id: number;
  cliente_id: number;
  cliente_nome?: string;
  profissional_id: number;
  profissional_nome?: string;
  servico_id: number | null;
  servico_nome: string | null;
  data_realizacao: string;
  valor: number;
  status: StatusAtendimento;
  observacoes: string | null;
  criado_em: string;
}

export interface DadosAtendimento {
  cliente_id: number;
  profissional_id: number;
  servico_id: number | null;
  data_realizacao: string;
  valor: number;
  status: StatusAtendimento;
  observacoes: string | null;
}

export interface AtualizacaoAtendimento extends DadosAtendimento {
  id: number;
}

export interface FiltroAtendimentos {
  clienteId?: number;
}
