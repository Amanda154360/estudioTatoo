import { CANAIS } from '../../shared/contracts/ipc';
import { idSchema } from '../../shared/validation/comum';
import {
  atualizacaoAtendimentoSchema,
  dadosAtendimentoSchema,
  filtroAtendimentosSchema,
} from '../../shared/validation/atendimentoSchemas';
import { AtendimentoService } from '../application/AtendimentoService';
import { SegurancaIpc } from './seguranca';

export function registrarAtendimentoIpc(): void {
  const servico = new AtendimentoService();

  SegurancaIpc.registrarCanal(CANAIS.atendimentoListar, filtroAtendimentosSchema, (filtro) =>
    servico.listar(filtro),
  );

  SegurancaIpc.registrarCanal(CANAIS.atendimentoListarPorCliente, idSchema, (clienteId) =>
    servico.listarHistoricoCliente(clienteId),
  );

  SegurancaIpc.registrarCanal(CANAIS.atendimentoRegistrar, dadosAtendimentoSchema, (dados) =>
    servico.registrar(dados),
  );

  SegurancaIpc.registrarCanal(CANAIS.atendimentoAtualizar, atualizacaoAtendimentoSchema, (dados) =>
    servico.atualizar(dados),
  );

  SegurancaIpc.registrarCanal(CANAIS.atendimentoExcluir, idSchema, (id) => servico.excluir(id));

  SegurancaIpc.registrarCanal(CANAIS.atendimentoUltimaVisita, idSchema, (clienteId) =>
    servico.ultimaVisita(clienteId),
  );
}
